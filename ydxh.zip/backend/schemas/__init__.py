# CineBook API Schemas
